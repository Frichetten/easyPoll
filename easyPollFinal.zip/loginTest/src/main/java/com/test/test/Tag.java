package com.test.test;

public class Tag {

	private String tag;
	private int pollNum;
	private int tagNum;
	
	public Tag(String tag, int pollNum, int tagNum){
		this.tag = tag;
		this.tagNum = tagNum;
		this.pollNum = pollNum;
	}
	
	public void setTag(String tag, String pollNum){
		
	}
	
	public int getTagNum(){
		
		return 0;
	}
	
}
